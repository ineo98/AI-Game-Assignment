package pacman.entries.pacman.wiba.bt;

public enum Status {
    RUNNING,
    SUCCESS,
    FAILURE,
    INVALID
}
