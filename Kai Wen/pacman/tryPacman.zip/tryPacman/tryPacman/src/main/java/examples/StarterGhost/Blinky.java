package examples.StarterGhost;

import pacman.game.Constants;

/**
 * Created by Piers on 11/11/2015.
 */
public class Blinky extends POGhost {


    public Blinky() {
        super(Constants.GHOST.BLINKY);
    }

}
