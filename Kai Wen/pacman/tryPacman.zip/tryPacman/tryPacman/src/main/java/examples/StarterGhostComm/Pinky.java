package examples.StarterGhostComm;

import pacman.game.Constants;

/**
 * Created by Piers on 11/11/2015.
 */
public class Pinky extends POCommGhost {

    public Pinky() {
        super(Constants.GHOST.PINKY, 50);
    }
}
