package examples.StarterGhostComm;

import pacman.game.Constants;

/**
 * Created by Piers on 11/11/2015.
 */
public class Inky extends POCommGhost {

    public Inky() {
        super(Constants.GHOST.INKY, 50);
    }

}
