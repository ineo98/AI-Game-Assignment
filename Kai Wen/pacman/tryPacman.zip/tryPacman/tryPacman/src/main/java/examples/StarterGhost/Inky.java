package examples.StarterGhost;

import pacman.game.Constants;

/**
 * Created by Piers on 11/11/2015.
 */
public class Inky extends POGhost {

    public Inky() {
        super(Constants.GHOST.INKY);
    }

}
