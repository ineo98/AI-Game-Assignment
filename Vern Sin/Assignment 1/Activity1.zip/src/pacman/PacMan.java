/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pacman;

/**
 *
 * @author Vern Sin
 */

import pacman.Constants.MOVE;

/*
 * Data structure to hold all information pertaining to Ms Pac-Man.
 */
public final class PacMan
{
	public int currentNodeIndex, numberOfLivesRemaining;
	public MOVE lastMoveMade;	
	public boolean hasReceivedExtraLife;
	
	public PacMan(int currentNodeIndex, MOVE lastMoveMade, int numberOfLivesRemaining, boolean hasReceivedExtraLife)
	{
		this.currentNodeIndex = currentNodeIndex;
		this.lastMoveMade = lastMoveMade;
		this.numberOfLivesRemaining = numberOfLivesRemaining;
		this.hasReceivedExtraLife = hasReceivedExtraLife;
	}
	
	public PacMan copy()
	{
		return new PacMan(currentNodeIndex, lastMoveMade, numberOfLivesRemaining, hasReceivedExtraLife);
	}
}