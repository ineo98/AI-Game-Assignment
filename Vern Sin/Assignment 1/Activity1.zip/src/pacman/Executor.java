/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pacman;

/**
 *
 * @author Vern Sin
 */

import java.util.EnumMap;
import java.util.Random;

import pacman.Controller;
import pacman.Legacy2TheReckoning;
import pacman.StarterPacMan;
import pacman.Game;
import pacman.GameView;
import static pacman.Constants.*;

/**
 * This class may be used to execute the game in timed or un-timed modes, with or without
 * visuals. Competitors should implement their controllers in game.entries.ghosts and 
 * game.entries.pacman respectively. The skeleton classes are already provided. The package
 * structure should not be changed (although you may create sub-packages in these packages).
 */
@SuppressWarnings("unused")
public class Executor{	
	/**
	 * The main method. Several options are listed - simply remove comments to use the option you want.
	 *
	 * @param args the command line arguments
	 */
    public static void main(String[] args){
	int delay=10;
	boolean visual=true;
	int numTrials=20;
		
	Executor exec=new Executor();
		
	/* run a game in synchronous mode: game waits until controllers respond. */
	System.out.println("STARTER PACMAN vs LEGACY2THERECKONING");
	exec.runGame(new StarterPacMan(), new Legacy2TheReckoning(), visual,delay);
		
	/* run multiple games in batch mode - good for testing. */
//	exec.runExperiment(new StarterPacMan(), new Legacy2TheReckoning(),numTrials);
    }
	
    public void runExperiment(Controller<MOVE> pacManController,Controller<EnumMap<GHOST,MOVE>> ghostController,int trials){
    	double avgScore=0;
    	
    	Random rnd=new Random(0);
	Game game;
		
	for(int i=0;i<trials;i++){
            game=new Game(rnd.nextLong());
			
            while(!game.gameOver()){
		game.advanceGame(pacManController.getMove(game.copy(),System.currentTimeMillis()+DELAY),
		ghostController.getMove(game.copy(),System.currentTimeMillis()+DELAY));
            }
			
            avgScore+=game.getScore();
            System.out.println(i+"\t"+game.getScore());
	}
		
	System.out.println(avgScore/trials);
    }
	
	/**
	 * Run a game in asynchronous mode: the game waits until a move is returned. In order to slow thing down in case
	 * the controllers return very quickly, a time limit can be used. If fasted gameplay is required, this delay
	 * should be put as 0.
	 *
	 * @param pacManController The Pac-Man controller
	 * @param ghostController The Ghosts controller
	 * @param visual Indicates whether or not to use visuals
	 * @param delay The delay between time-steps
	 */
	public void runGame(Controller<MOVE> pacManController,Controller<EnumMap<GHOST,MOVE>> ghostController,boolean visual,int delay)
	{
		Game game=new Game(0);

		GameView gv=null;
		
		if(visual)
			gv=new GameView(game).showGame();
		
		while(!game.gameOver())
		{
	        game.advanceGame(pacManController.getMove(game.copy(),-1),ghostController.getMove(game.copy(),-1));
	        
	        try{Thread.sleep(delay);}catch(Exception e){}
	        
	        if(visual)
	        	gv.repaint();
		}
	}
}