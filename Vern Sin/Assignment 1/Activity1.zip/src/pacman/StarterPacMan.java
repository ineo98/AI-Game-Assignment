/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pacman;

/**
 *
 * @author Vern Sin
 */

import java.util.ArrayList;
import pacman.Constants.MOVE;
import pacman.Controller;
import pacman.Game;

import static pacman.Constants.*;

/* This controller utilises 3 tactics, in order of importance:
 * 1. Get away from any non-edible ghost that is in close proximity
 * 2. Go after the nearest edible ghost
 * 3. Go to the nearest pill/power pill
 */
public class StarterPacMan extends Controller<MOVE>{	
    private static final int MIN_DISTANCE=10;	//if a ghost is this close, run away
	
    public MOVE getMove(Game game,long timeDue){			
	int current=game.getPacmanCurrentNodeIndex();
        
        //Strategy 1: if any non-edible ghost is too close (less than MIN_DISTANCE), run away
	for(GHOST ghost : GHOST.values())
            if(game.getGhostEdibleTime(ghost)==0 && game.getGhostLairTime(ghost)==0)
		if(game.getShortestPathDistance(current,game.getGhostCurrentNodeIndex(ghost))<MIN_DISTANCE){
                    int[]powerPills = game.getActivePowerPillsIndices();
                    for(int ind_powerPill:powerPills){
                        if(game.getShortestPathDistance(current,game.getGhostCurrentNodeIndex(ghost))>ind_powerPill)
                            return game.getNextMoveTowardsTarget(game.getPacmanCurrentNodeIndex(),ind_powerPill,DM.PATH);
                    }
                    return game.getNextMoveAwayFromTarget(game.getPacmanCurrentNodeIndex(),game.getGhostCurrentNodeIndex(ghost),DM.PATH);
                }
        
	//Strategy 2: find the nearest edible ghost and go after them 
	int minDistance=Integer.MAX_VALUE;
	GHOST minGhost=null;		
		
	for(GHOST ghost : GHOST.values())
            if(game.getGhostEdibleTime(ghost)>0){
		int distance=game.getShortestPathDistance(current,game.getGhostCurrentNodeIndex(ghost));
				
		if(distance<minDistance){
                    minDistance=distance;
                    minGhost=ghost;
                }
            }
		
	if(minGhost!=null)	//we found an edible ghost
            return game.getNextMoveTowardsTarget(game.getPacmanCurrentNodeIndex(),game.getGhostCurrentNodeIndex(minGhost),DM.PATH);
		
	//Strategy 3: go after the pills and power pills
	int[] pills=game.getPillIndices();
	int[] powerPills=game.getPowerPillIndices();		
		
	ArrayList<Integer> targets=new ArrayList<Integer>();
		
	for(int i=powerPills.length-1;i>=0;i--)					//check which pills are available			
            if(game.isPillStillAvailable(i))
		targets.add(pills[i]);
		
	for(int i=powerPills.length-1;i>=0;i--)			//check with power pills are available
            if(game.isPowerPillStillAvailable(i))
		targets.add(powerPills[i]);				
		
	int[] targetsArray=new int[targets.size()];		//convert from ArrayList to array
		
	for(int i=0;i<targetsArray.length;i++)
            targetsArray[i]=targets.get(i);
		
	//return the next direction once the closest target has been identified
	return game.getNextMoveTowardsTarget(current,game.getClosestNodeIndexFromNodeIndex(current,targetsArray,DM.PATH),DM.PATH);
        
//-----------------------------------------------------------------------------------------------------------------------------------
//        //Strategy 1: if any non-edible ghost is too close (less than MIN_DISTANCE), run away
//	for(GHOST ghost : GHOST.values())
//            if(game.getGhostEdibleTime(ghost)==0 && game.getGhostLairTime(ghost)==0)
//		if(game.getShortestPathDistance(current,game.getGhostCurrentNodeIndex(ghost))<MIN_DISTANCE)
//                    return game.getNextMoveAwayFromTarget(game.getPacmanCurrentNodeIndex(),game.getGhostCurrentNodeIndex(ghost),DM.PATH);
//		
//	//Strategy 2: find the nearest edible ghost and go after them 
//	int minDistance=Integer.MAX_VALUE;
//	GHOST minGhost=null;		
//		
//	for(GHOST ghost : GHOST.values())
//            if(game.getGhostEdibleTime(ghost)>0){
//		int distance=game.getShortestPathDistance(current,game.getGhostCurrentNodeIndex(ghost));
//				
//		if(distance<minDistance){
//                    minDistance=distance;
//                    minGhost=ghost;
//                }
//            }
//		
//	if(minGhost!=null)	//we found an edible ghost
//            return game.getNextMoveTowardsTarget(game.getPacmanCurrentNodeIndex(),game.getGhostCurrentNodeIndex(minGhost),DM.PATH);
//		
//	//Strategy 3: go after the pills and power pills
//	int[] pills=game.getPillIndices();
//	int[] powerPills=game.getPowerPillIndices();		
//		
//	ArrayList<Integer> targets=new ArrayList<Integer>();
//		
//	for(int i=0;i<pills.length;i++)					//check which pills are available			
//            if(game.isPillStillAvailable(i))
//		targets.add(pills[i]);
//		
//	for(int i=0;i<powerPills.length;i++)			//check with power pills are available
//            if(game.isPowerPillStillAvailable(i))
//		targets.add(powerPills[i]);				
//		
//	int[] targetsArray=new int[targets.size()];		//convert from ArrayList to array
//		
//	for(int i=0;i<targetsArray.length;i++)
//            targetsArray[i]=targets.get(i);
//		
//	//return the next direction once the closest target has been identified
//	return game.getNextMoveTowardsTarget(current,game.getClosestNodeIndexFromNodeIndex(current,targetsArray,DM.PATH),DM.PATH);
    }
}