# Changelog
## [1.0.5] - 2020-11-04
- Removed pdb files
  
## [1.0.4] - 2020-11-03
- Added the portable-pdb (DSTR-37)
  
## [1.0.3] - 2020-10-30
- Fixed being able to load mdb or portable-pdb symbolsbug (DSTR-37)
- Minimum unity version updated (case 1279253)

## [1.0.2] - 2019-12-04

- Added missed metafiles

## [0.0.1] - 2019-02-21

### This is the first release of *Unity Package com.unity.ext.nunit*.

- Migrated the custom version of nunit from inside of unity.
